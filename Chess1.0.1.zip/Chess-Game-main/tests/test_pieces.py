import unittest
from chess_game.Pieces import Pawn, Rook, Bishop, Knight, Queen, King
from chess_game.constants import White, Black, Black_Pawn, White_Pawn, Black_Rook, White_Rook, Black_Bishop, \
    White_Bishop, Black_Knight, White_Knight, Black_Queen, White_Queen, Black_King, White_King


class TestChessPieces(unittest.TestCase):

    def setUp(self):
        self.board = [[0 for _ in range(8)] for _ in range(8)]

    def test_white_pawn_moves(self):
        white_pawn = Pawn(60, White_Pawn, White, "Pawn", 6, 0)
        self.board[6][0] = white_pawn
        moves = white_pawn.get_available_moves(6, 0, self.board)
        expected_moves = [(5, 0), (4, 0)]
        self.assertEqual(set(moves), set(expected_moves))

    def test_black_pawn_moves(self):
        black_pawn = Pawn(60, Black_Pawn, Black, "Pawn", 1, 0)
        self.board[1][0] = black_pawn
        moves = black_pawn.get_available_moves(1, 0, self.board)
        expected_moves = [(2, 0), (3, 0)]
        self.assertEqual(set(moves), set(expected_moves))

    def test_white_pawn_capture(self):
        white_pawn = Pawn(60, White_Pawn, White, "Pawn", 6, 0)
        black_pawn = Pawn(60, Black_Pawn, Black, "Pawn", 5, 1)
        self.board[6][0] = white_pawn
        self.board[5][1] = black_pawn
        moves = white_pawn.get_available_moves(6, 0, self.board)
        expected_moves = [(5, 0), (4, 0), (5, 1)]
        self.assertEqual(set(moves), set(expected_moves))

    def test_rook_moves(self):
        rook = Rook(60, White_Rook, White, "Rook", 0, 0)
        self.board[0][0] = rook
        moves = rook.get_available_moves(0, 0, self.board)
        expected_moves = [(1, 0), (2, 0), (3, 0), (4, 0), (5, 0), (6, 0), (7, 0),
                          (0, 1), (0, 2), (0, 3), (0, 4), (0, 5), (0, 6), (0, 7)]
        self.assertEqual(set(moves), set(expected_moves))

    def test_bishop_moves(self):
        bishop = Bishop(60, White_Bishop, White, "Bishop", 4, 4)
        self.board[4][4] = bishop
        moves = bishop.get_available_moves(4, 4, self.board)
        expected_moves = [(5, 5), (6, 6), (7, 7), (3, 3), (2, 2), (1, 1), (0, 0),
                          (3, 5), (2, 6), (1, 7), (5, 3), (6, 2), (7, 1)]
        self.assertEqual(set(moves), set(expected_moves))

    def test_knight_moves(self):
        knight = Knight(60, White_Knight, White, "Knight", 4, 4)
        self.board[4][4] = knight
        moves = knight.get_available_moves(4, 4, self.board)
        expected_moves = [(2, 5), (3, 6), (5, 6), (6, 5), (6, 3), (5, 2), (3, 2), (2, 3)]
        self.assertEqual(set(moves), set(expected_moves))

    def test_queen_moves(self):
        queen = Queen(60, White_Queen, White, "Queen", 4, 4)
        self.board[4][4] = queen
        moves = queen.get_available_moves(4, 4, self.board)
        expected_moves = [(5, 5), (6, 6), (7, 7), (3, 3), (2, 2), (1, 1), (0, 0),
                          (3, 5), (2, 6), (1, 7), (5, 3), (6, 2), (7, 1),
                          (5, 4), (6, 4), (7, 4), (3, 4), (2, 4), (1, 4), (0, 4),
                          (4, 5), (4, 6), (4, 7), (4, 3), (4, 2), (4, 1), (4, 0)]
        self.assertEqual(set(moves), set(expected_moves))

    def test_king_moves(self):
        king = King(60, White_King, White, "King", 4, 4)
        self.board[4][4] = king
        moves = king.get_available_moves(4, 4, self.board)
        expected_moves = [(3, 4), (5, 4), (4, 3), (4, 5), (3, 3), (3, 5), (5, 3), (5, 5)]
        self.assertEqual(set(moves), set(expected_moves))


if __name__ == '__main__':
    unittest.main()
